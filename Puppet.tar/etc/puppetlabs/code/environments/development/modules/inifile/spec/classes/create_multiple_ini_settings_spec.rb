require 'spec_helper'

describe 'create_multiple_ini_settings' do
  it { is_expected.to compile }
end
