Facter.add(:tomcat_service_name) do
  setcode do 
    if File.exists?('/etc/init.d/tomcat12')
      'tomcat12'
    elsif File.exists?('/etc/init.d/tomcat')
      'tomcat'
    else
      nil
    end
  end
end
