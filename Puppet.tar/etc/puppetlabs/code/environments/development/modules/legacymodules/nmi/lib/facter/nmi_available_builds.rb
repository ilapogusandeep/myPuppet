require 'facter'
Facter.add(:nmi_available_builds) do
  setcode do
    builds = []
    Dir['/nfs_share/deployables/*'].each do |v_path|
      Dir["#{v_path}/*"].each do |app|
	app_name    = File.basename(app)
        if app_name == 'rules-server'
        app_name = 'rules-server'
        #app_name    = File.basename(app)
        #elsif app_name == 'drools'
        #app_name = 'rules-server'
        elsif app_name == 'mq'
          app_name = 'workflowservice'   
        end
        app_version = File.basename(v_path)
        builds.push("#{app_name}-#{app_version}")
      end
    end
    builds.join(',')
  end
end
