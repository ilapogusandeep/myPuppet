# Facter.add(:nmi_machine_group) do
#   setcode do
#     splt_hn = Facter[:hostname].value.split('-')
#     raise("Found incorrect hostname #{Facter[:hostname].value}") unless splt_hn.size == 4
#     case splt_hn[0]
#     when 'msp'
#       'staging'
#     when 'msn'
#       'dev'
#     when 'int'
#       'integration'
#     when 'fit'
#       'production'
#     else
#       'unknown'
#     end
#   end
# end
