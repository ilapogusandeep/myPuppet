#! /bin/sh
#
##############################
## CIS-CAT Security Updates ##
#############################
#
### Software Removal ###
#
yum -y erase telnet-server
yum -y erase xinetd
#
### Application start up change ###
#
chkconfig chargen-dgram off 
chkconfig chargen-stream off
chkconfig tcpmux-server off
#
### Fstab Mount Updates ###
#
#sed -i '/VolGroup00-tmp/s/defaults/nodev,nosuid,noexec/g' /etc/fstab
sed -i '/shm/s/defaults/nodev,nosuid,noexec/g' /etc/fstab
echo -e '/tmp/\t\t\t/var/tmp \t\t\tnone\tbind\t\t0 0' >> /etc/fstab
#
### Mounts ###
#
#mount -o remount,nodev,nosuid,noexec /tmp
#mount -o remount,nodev /tmp 
#mount -o remount,nosuid /tmp 
#mount -o remount,noexec /tmp 
#mount --bind /tmp /var/tmp 
mount -o remount,nodev,nosuid,noexec /dev/shm 
mount -o remount,nodev /dev/shm 
mount -o remount,nosuid /dev/shm
mount -o remount,noexec /dev/shm
mount -o remount,nodev /home 
df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null | xargs chmod a+t
#
### System Control Resets ###
#
/sbin/sysctl -w net.ipv4.conf.all.send_redirects=0
/sbin/sysctl -w net.ipv4.conf.default.send_redirects=0
/sbin/sysctl -w net.ipv4.route.flush=1
/sbin/sysctl -w net.ipv4.conf.all.accept_redirects=0
/sbin/sysctl -w net.ipv4.conf.default.accept_redirects=0
/sbin/sysctl -w net.ipv4.route.flush=1
/sbin/sysctl -w net.ipv4.conf.all.secure_redirects=0
/sbin/sysctl -w net.ipv4.conf.default.secure_redirects=0
/sbin/sysctl -w net.ipv4.route.flush=1
/sbin/sysctl -w net.ipv4.conf.all.log_martians=1
/sbin/sysctl -w net.ipv4.conf.default.log_martians=1
/sbin/sysctl -w net.ipv4.route.flush=1
/sbin/sysctl -w net.ipv4.conf.all.rp_filter=1
/sbin/sysctl -w net.ipv4.conf.default.rp_filter=1
/sbin/sysctl -w net.ipv4.route.flush=1
#
### Service stop / restart ###
#
service auditd restart
#
### Cron Updates###
#
/bin/rm /etc/cron.deny
/bin/rm /etc/at.deny
touch /etc/at.allow
touch /etc/cron.allow 
chmod og-rwx /etc/cron.hourly
chmod og-rwx /etc/cron.daily
chmod og-rwx /etc/cron.weekly
chmod og-rwx /etc/cron.monthly
chmod og-rwx /etc/cron.d
chmod og-rwx /etc/crontab
chmod og-rwx /etc/cron.allow
chmod og-rwx /etc/at.allow
chmod g-wx,o-rwx /var/log/all.log
chown root:root /etc/cron.allow
chown root:root /etc/at.allow
