#!/usr/bin/perl
@tavant= ( "sashok", "bmadmin", "saadmin", "gvadmin", "htadmin", "tmadmin", "jbadmin", "oladmin", "cjadmin", "dfadmin", "pradeepb", "harshan","praveenk", "Sunil.ha", "sandhya.suku", "saadmin", "smadmin", "rkadmin", "gaadmin", "psadmin", "vkadmin");
use File::Spec;
open STDERR, '>', File::Spec->devnull() or die "could not open STDERR: $!\n";
foreach $i (@tavant) {
    
     `chage $i -W 7`;
     `chage $i -m 1`;
     `chage $i -M 90`;
     `chage $i -d 0`;

done;

}
