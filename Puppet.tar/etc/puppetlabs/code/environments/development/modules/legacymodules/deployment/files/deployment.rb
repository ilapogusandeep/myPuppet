module MCollective
  module Agent
    class Deployment < RPC::Agent
      require 'rubygems'	
      require 'fileutils'
      require 'logger'	
      require 'net/ssh'
      require 'net/scp'

      action 'deploy' do
        begin
        # Load facts
        role = Facts['nmi_role']
        tomcat_service_name = Facts['tomcat_service_name']
        warpath = Facts['warpath']
        environment =  Facts['environment']

        # Get deployment version
        version = request[:version]

        # Instantiate an executor
        executor = Executor.new

        # START THE DEPLOYMENT PROCESS////////////////////////////////////////////

        # Stop Tomcat Service
        executor.run("service #{tomcat_service_name} stop")
	
        # Remove remaining artifacts
        #if File.directory?("/usr/share/apache-tomcat/webapps")
        #  Dir::foreach("/usr/share/apache-tomcat/webapps") do |fn|
        #    FileUtils.rm_rf '*.war' unless fn == 'ROOT' or fn == '.' or fn == '..'
        #  end
        # end

        # Remove Old War Files
        executor.run("rm -f /usr/share/apache-tomcat/webapps/*.war")

        # Fetch WAR
         executor.run("wget -cnv http://puppet/#{version}/#{role}/war/#{role}.war -O #{warpath}/webapps/#{role}.war")

	# NEW SCP FETCH TRANSFER ////////////////////////////////////////
        #HOST = 'puppet'
        #USER = 'jwadmin'
        #PASS = 'Riversidebuddy1^'
        #Net::SSH.start( HOST, USER, :password => PASS )do|ssh|
	#ssh.scp.download!("/var/artifacts/#{version}/#{role}/war/#{role}.war", "#{warpath}/webapps/#{role}.war")
	#end

        # Fetch Configs
        #executor.run("wget -nv http://puppet/#{version}/#{role}/conf/#{environment}/*  -O /tmp/conf.tar")
        #executor.run("tar -xf /tmp/conf.tar -C /opt/axis/#{role}/conf")
        #executor.run("rm -f /tmp/conf.tar")

        # Start Tomcat Service
        executor.run("service #{tomcat_service_name} start")

        # END THE DEPLOYMENT PROCESS////////////////////////////////////////////

        # REMOVE OLD TARBALLS///////////////////////////////////////////////////
        executor.run("rm -f /var/artifacts/#{version}.tar")

        # Return executor log
        reply[:output] = executor.log

        # Handle any exceptions and return the message
        rescue Exception => e
          reply[:output] = String(e.message)
        end
      end

      class Executor
        attr_reader :log

        def initialize
          @log = []
        end

        def run(cmd)
          output = `#{cmd} 2>&1`
          @log << output
          if $?.exitstatus != 0
            raise String(output)
          end
        end
      end

    end
  end
end
