#!/bin/bash
#
#
DATE=`/bin/date +%m%d%y`
BUILD="ECM-2016-04" ## Will change.
AMP="502.8" ## this will change
ENV="linstg" ## change your environment
ALF="alf03" ## for Staging environment only -- change server

cd  /opt/alfresco/artifacts

unzip Files.zip && unzip  ECM-2016-04*.zip

## uncomment next line out if global properties needs to be backed up

echo Making a backup copy of *.properties file......

#mv /opt/alfresco/tomcat/shared/classes/alfresco-global.properties /opt/alfresco/tomcat/shared/classes/alfresco-global.properties.bak-${DATE}
#cp /opt/alfresco/artifacts/${BUILD}-*/${ALF}-alfresco-global.properties /opt/alfresco/tomcat/shared/classes/alfresco-global.properties

#mv /opt/alfresco/tomcat/shared/classes/customer-mappings.properties /opt/alfresco/tomcat/shared/classes/customer-mappings.properties.bak-${DATE}

#cp /opt/alfresco/artifacts/${BUILD}-*/customer-mappings.properties /opt/alfresco/tomcat/shared/classes/customer-mappings.properties

echo Stopping services solr and alfresco..

service solr stop && service alfresco stop

echo Copying amp files to /opt/alfresco/amps.....

cp /opt/alfresco/artifacts/ECM-2016-04-${ENV}/nmicm-Explorer-amp-${AMP}-${ENV}.amp /opt/alfresco/amps/

sleep 5

cp /opt/alfresco/artifacts/ECM-2016-04-${ENV}/nmicm-Share-amp-${AMP}-${ENV}.amp /opt/alfresco/amps_share/

sleep 5

echo Making a backup copy of current alfresco and share war file....

mv /opt/alfresco/tomcat/webapps/alfresco.war /opt/alfresco/tomcat/webapps/alfresco.war.bak-${DATE}

mv /opt/alfresco/tomcat/webapps/share.war /opt/alfresco/tomcat/webapps/share.war.bak-${DATE}

sleep 5

echo copying *.war.orig to /opt/alfresco/tomcat/webapps.....

cp /opt/alfresco/tomcat/webapps/alfresco.war.orig /opt/alfresco/tomcat/webapps/alfresco.war

cp /opt/alfresco/tomcat/webapps/share.war.orig /opt/alfresco/tomcat/webapps/share.war

echo Applying amps file to alfresco and share war files....

/opt/alfresco/java/bin/java -jar /opt/alfresco/bin/alfresco-mmt.jar install /opt/alfresco/amps/nmicm-Explorer-amp-502.8-${ENV}.amp /opt/alfresco/tomcat/webapps/alfresco.war

/opt/alfresco/java/bin/java -jar /opt/alfresco/bin/alfresco-mmt.jar install /opt/alfresco/amps_share/nmicm-Share-amp-502.8-${ENV}.amp /opt/alfresco/tomcat/webapps/share.war -force

echo Verifying that AMP files have been installed successfully......
#
/opt/alfresco/java/bin/java -jar /opt/alfresco/bin/alfresco-mmt.jar list /opt/alfresco/tomcat/webapps/alfresco.war

/opt/alfresco/java/bin/java -jar /opt/alfresco/bin/alfresco-mmt.jar list /opt/alfresco/tomcat/webapps/share.war

sleep 5

echo Removing old webapps directories....

rm -rf /opt/alfresco/tomcat/webapps/alfresco/

rm -rf /opt/alfresco/tomcat/webapps/share/

echo Extracting updated WAR files.....

unzip -q /opt/alfresco/tomcat/webapps/alfresco.war -d /opt/alfresco/tomcat/webapps/alfresco

unzip -q /opt/alfresco/tomcat/webapps/share.war -d /opt/alfresco/tomcat/webapps/share

sleep 5

echo Restarting Alfresco and then solr services....

service alfresco start && service solr start

sleep 5

tail -f /opt/alfresco/tomcat/logs/alfresco.log
