#!/bin/env ruby
require 'json'
require 'timeout'
require 'yaml'


version       = ARGV[0] || raise('Must pass version')
role          = ARGV[1] || raise('Must pass role')
machine_group = ARGV[2] || raise('Must pass machine group') 
filters       = ARGV[3] || raise('Must pass filter')

timeout = 300

yaml_file = "/etc/puppetlabs/hiera/data/machine_group/#{machine_group}.yaml"

group_yaml = File.exists?(yaml_file)? YAML.load_file(yaml_file) : {}
group_yaml ||= {}

group_yaml["nmi::profiles::#{role.gsub('-', '_')}::version"] = version

File.open(yaml_file, 'w') do |fh|
  fh.write(group_yaml.to_yaml)
end

# I might need to add some more intelligent filtering of nodes here
# TODO unset no-sply when we want to do more than a few at a time
run_output = `mco puppet runonce -j --no-noop --no-splay #{filters}`

puts run_output

run_results = JSON.parse(run_output)

# get the list of all hosts that we ran puppet on

hosts = run_results.collect do |x|
  if x['statusmsg'] != 'OK'
    raise("Node failed: #{x.inspect}")
  end
  x['sender']
end

# check the status of all hosts, and block until
# they have all completed their puppet runs

# rigt now this just checks and matches count
# checking and matching hostnames would be more
# robust
#
# This is also not checking to see if all agents
# have completed their runs
#
completed_hosts = []
all_hosts       = []
Timeout::timeout(timeout) do

  while completed_hosts.size < hosts.size

    hosts_complete = 0
    status_output = `mco puppet status -j #{filters}`
    puts status_output

    status_output.split("\n").each do |line|
      if line =~ /(\S+): Currently stopped/
        completed_hosts.push($1)
        all_hosts.push($1)
      elsif line =~ /\s*(\S+): .*/
        all_hosts.push($1)
      end
    end
  end

end


# check that the host names match between the completed hosts and
# the hosts that we initiated Puppet on
#

if completed_hosts.size != all_hosts.size
  puts "status returned uncompleted hosts: #{all_hosts - completed_hosts}"
end

if all_hosts.size != hosts.size
  puts "Status shows more hosts than puppet ran on #{all_hosts - hosts}"
end

summary=`mco puppet summary -j #{filters}`

puts summary

summary.split("\n").each do |line|
  if line =~ /Total resources:.*?(\d+\.\d+).*?(\d+\.\d+)/
    if $1 == '0.0'
      raise("Some nodes report zero resources. This probably indicates a catalog failure")
    end
  end
end
