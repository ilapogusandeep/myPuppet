Facter.add('nmi_environment') do
  setcode do
	case Facter.value(:hostname) 
	when /^dev.*$/
		'dev'
	when /^msn.*$/
		'qa'
	when /^msp.*$/
		'stg'
	when /^fit.*$/
		'prod'
	when /^int.*$/
		'ci'
	when /^pss.*$/
		'prod'
	when /^emv.*$/
		'test'
	else
		nil
	end
  end
end
