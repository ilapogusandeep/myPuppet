## installation:

1. sync the module repo to your master
2. add the following to site.pp

````
node '<master_hostname>' {
  include nmi::master
}
````

3. Configure the master

On the master, run:

````
puppet agent -t
````

4. Add nmi base class to default node

````
node default {
  include nmi
}
````

5. configure all puppet agents

if mcollective is already configured:

````
mco puppet runonce
````

if it is not installed, on each agent:

````
puppet agent -t --no-noop
````

6. use orchestration tools to start deploying

## facts

We have created  4 custom facts that are used to aid with war file deployments.

The source for these facts can be found in this module at:

  ./lib/facter

* nmi_available_builds - scans the contents of /nfs_share/deployables to determine the current
build versions that are available for each role. This is returned as a comma delimited list
that is used by the deploy.sh script to check for invalid versions.

* nmi_build_version - returns the current build version installed on a machine. It retrieves this
information by parsing _buildNo_ from _properties/environment.properties_.

* nmi_machine_group - uses the hostname to determine the machines environment (production,
staging,dev,etc). This is used as a filter to determine which machines to set a version for by
deploy.sh.

* nmi_role - detects the current role. It parses the config directory to make this determination.
If /opt/axis/ contains more than one directory, this fact returns Unknown.


NOTE: facts are updated for usage by mcollective as filters every 15 minuites from cron on each agent.
Deployment runs will auto-update facts if the role version changes.

To updat these facts, run the following command on each server (or the desired server)

````
/opt/puppet/sbin/refresh-mcollective-metadata
````

NOTE: facts for puppetdb are updated when the puppet agent runs.

It is possible b/c of this for these two different sources to have different versions.

## site manifests

The site manifest is used to map each node to its desired role.

There are two ways to do this:

1. Matching based on nmi_role

````
if $nmi_role == 'rules-server' {
  include nmi::profiles::rules_server
} elsif $nmi_role == 'sso' {
  include nmi::profiles::sso
} elsif $nmi_role == 'origination' {
  include nmi::profiles::origination
} elsif $nmi_role == 'workflowservice' {
  include nmi::profiles::workflowservice
} elsif $nmi_role == 'servicing' {
  include nmi::profiles::servicing
}

````

- Advantage - easy to maintain.
- Disadvantage - you have to immediately set a build_version in hiera
for each role or puppet cannot compile. This means that you cannot perform the
initial puppet run to configure mcollective.

2. node based matching (which is what should be used)

match each nodes certname to its role:

````
node 'fit-lin-tcat-01', 'fit-lin-tcat-02'  {
  include nmi::profiles::origination
}
````

- disadvantages - have to manually add each new server
- advantages - allows you to first perform initial provisioning (for mcollective)
before adding the nmi roles

## hiera

we are mainly setting variables for class parameters through hiera via the
nmi_machine_group fact. In fact, the deploy.sh script writes out the version
to use for each deployment into the nmi_machie_group specific file.

Ie: if we run:

````
bash bin/deploy.sh 0.7.5.0 origination production
````

This script will write the value

````
nmi::profiles::origination::version: 0.7.5.0
````

into the file: /etc/puppetlabs/hiera/data/machine_group/production.yaml

In the future, hiera will likely be used to populate more environment
specific information (nameservers, timeservers, db servers, etc).

## profiles

The profiles in this module perform the way deployments. Each application has its
own profile that can be found in manifests/profiles/<role>.pp.

These profiles are responsible for providing config to tune the jvm as well as
deploying the way artifacts.

## deployment script

the deployment scripts are run as the peadmin on the puppet master.

````
su - peadmin
````

The scripts are located in peadmins home directory /var/lib/peadmin/bin.

In order to perform a deployment, run the following script:

````
bash bin/deploy.sh <version> <role> <machine_group>
````

ie:

````
bash bin/deploy.sh 0.7.5.0 origination production
````

This script does the following:

1. create a filter for all mcollective commands using machine group and role
(ie: -F nmi_machine_group=<machine_group> nmi_role=<role>)

for all machines that match that filter
  2. verifies that role and version combination are valid using nmi_avilable build 
  3. pings and displays all servers that respond to filter
  4. displays current build version for all servers that respond to filters
  5. stops puppet agent
  6. stops tomcat 
  7. calls out to puppet script
    8. Writes out version for role to hiera file: /etc/puppetlabs/hiera/data/machine_group/#{machine_group}.yaml
    9. forces all machines to run with no-noop (live run)
   10. monitors status of all machines to determine when runs complete
   11. displays the resulting summaries for those runs
  12. starts puppet agent
  13. starts tomcat 

NOTE: the directory with all of these files is deployed via puppet from this modules files/peadmin
dir. DO NOT MAKE CHANGES TO THE /var/lib/peadmin version, they may be overridden!!!!!
