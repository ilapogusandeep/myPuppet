#!/bin/bash
#set -e
set -u

version=$1
role=$2
machine_group=$3

filter="-F nmi_role=$2 -F nmi_machine_group=$3"

if mco facts nmi_available_builds $filter | grep $role-$version ; then
  echo "Version: ${version} is valid"
else
  echo "Combination of version/role ${role}-${version} is not valid"
  mco facts nmi_available_builds $filter
  exit 1
fi

mco ping $filter

mco facts nmi_build_version $filter

# first disable puppet agent on all machines
mco service pe-puppet stop $filter

mco service tomcat stop $filter

ruby `dirname $0`/run_puppet.rb $version $role $machine_group "$filter"

# resume tomcat service
mco service tomcat start $filter

# finally reenable puppet
mco service pe-puppet start $filter
