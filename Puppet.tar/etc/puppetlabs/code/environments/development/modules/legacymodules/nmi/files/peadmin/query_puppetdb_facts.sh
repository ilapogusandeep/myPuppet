#!/bin/bash
echo $1
curl -X GET http://127.0.0.1:8080/v3/facts --data-urlencode "query=[\"=\", \"name\", \"$1\"]"
