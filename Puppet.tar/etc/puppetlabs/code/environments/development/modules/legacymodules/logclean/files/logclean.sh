!#/bin/bash

find /usr/share/apache-tomcat/logs -mtime +180 -exec rm {} \;

find /opt/axis/*/logs -mtime +180 -exec rm {} \;
