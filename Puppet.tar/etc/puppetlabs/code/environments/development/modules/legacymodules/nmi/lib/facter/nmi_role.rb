Facter.add('nmi_role') do
  setcode do
    files = Dir['/opt/axis/*']
    if files.size == 0
      "Nothing"
    elsif files.size == 1
      File.basename(files.first)
    else
      "Unknown"
    end
  end
end
