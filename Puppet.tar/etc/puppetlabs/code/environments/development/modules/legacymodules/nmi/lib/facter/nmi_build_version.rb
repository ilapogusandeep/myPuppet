def find_build_line(path)
  if File.exists?(path)
    File.readlines(path).each do |line|
      if line =~ /buildNo\s*=\s*(\S+)/
        return $1 
      end
    end
    raise('Found file with no build number')
  else
    'No Build'
  end
end

Facter.add('nmi_build_version') do
  setcode do
    role = Facter[:nmi_role].value
    common_path = role == 'sso' ? '' : 'common' 
    path = File.join('/opt/axis/', role, "conf/#{common_path}/properties/environment.properties")
    find_build_line(path)
  end
end
