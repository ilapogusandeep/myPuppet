Facter.add(:warpath) do
  [ '/usr/share/apache-tomcat', '/usr/share/apache-tomcat-12' ].each do |i|
    if Dir.exists?(i)
      setcode do 
        i
      end
    end
  end
end
