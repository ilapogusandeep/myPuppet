#!/bin/bash

branch=`git branch | grep '\*' | cut -d" " -f2`
dirty=`git diff --shortstat |wc -l`
if [ $dirty -eq 1 ]; then
  git stash
fi

for b in development staging qa production ; do
	git checkout $b
	git pull -r origin $b
done

git checkout $branch
if [ $dirty -eq 1 ]; then
  git stash pop
fi
