Facter.add('nmi_datacenter') do
  setcode do
    require 'ipaddr'

    FIT = [
      '10.1.89.0/24',
      '10.1.92.0/24',
      '10.1.133.0/24',
      '10.1.136.0/24'
    ]
    MSN = [
      '10.1.93.0/24',
      '10.1.128.0/24',
      '10.1.77.0/24',
      '10.1.160.0/24',
      '10.1.161.0/24',
      '10.1.162.0/24'
    ]
    MSP = [
      '10.10.89.0/24',
      '10.10.92.0/24',
      '10.10.133.0/24',
      '10.20.89.0/24',
      '10.20.92.0/24',
      '10.20.133.0/24'
    ]
    WHQ = [
      '172.16.2.0/24',
      '172.16.4.0/24',
      '172.16.5.0/24'
    ]

    def check_ranges ip,nets
      nets.each do |net|
        if IPAddr.new(net) === IPAddr.new(ip)
          return true
        end
      end
      return false
    end

    ip = Facter.value(:ipaddress)

    if check_ranges ip, FIT
      'fit'
    elsif check_ranges ip, MSN
      'msn'
    elsif check_ranges ip, MSP
      'msp'
    elsif check_ranges ip, WHQ
      'whq'
    else
      nil
    end
  end
end
