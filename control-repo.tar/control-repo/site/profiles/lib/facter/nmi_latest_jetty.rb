Facter.add('nmi_latest_jetty') do
  setcode do
    require 'puppet'

    basepath = '/usr/share'
    files = Dir.entries(basepath).select { |d| /^jetty-distribution-[0-9\.v]+$/.match(d) }
    files.reject! { |f| File.lstat("#{basepath}/#{f}").symlink? }
    files.select! { |f| File.lstat("#{basepath}/#{f}").directory? }
    files.sort! { |a,b| Puppet::Util::Package.versioncmp(a.split('-')[2], b.split('-')[2]) }

    if(files.nil? or files == [])
      nil
    else
      files[-1]
    end
  end
end
