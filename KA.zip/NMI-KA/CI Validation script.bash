#!/bin/bash

echo_ok() {
  echo -n "["
  echo -en "\\033[1;32m"
  echo -n OK
  echo -en "\\033[0;39m"
  echo "]"
}

echo_fail() {
  echo -n "["
  echo -en "\\033[1;31m"
  echo -n FAIL
  echo -en "\\033[0;39m"
  echo "]"
}

# $1 URL
# $2 expected HTTP code
check_service() {
  echo -en "$1\t\t"
  out=`curl -L -k -o /dev/null -w '%{http_code}' -s  ${1}`
  if [ $out = $2 ]; then
    echo_ok
  else
    echo_fail
  fi
}

# $1 service name (e.g., batchprocess)
# $2 server names (e.g., '10.10.89.42:8443 10.10.89.43:8443 10.10.89.44:8443' - quotes matter)
# $3 expected HTTP code
check_servers() {
  echo '####################################'
  echo "# Checking ${1}                    #"
  echo '####################################'
  for server in $2; do
    check_service $server $3
  done
  echo
  echo
}

check_servers batchprocess 'https://10.20.89.41:8443/batchprocess/admin' '401'
check_servers sso 'https://10.20.89.129:9443/axis/login' '200'
check_servers origination 'https://10.20.89.26:9443/origination' '200'
check_servers servicing 'https://10.20.89.27:9443/servicing/' '200'
check_servers drools 'https://10.20.89.23:9443/rules-service/rules/eligibility' '401'
check_servers erq 'https://10.20.89.28:8443/NMISync/ratequoteservice/getratequote' '401'
check_servers scheduler 'https://10.20.89.120:9443/scheduler/app/scheduler/paymentProcessing' '401'
check_servers notification 'https://10.20.89.27:18443/notification-server' '200'
