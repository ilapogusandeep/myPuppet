Facter.add('nmi_latest_jetty') do
  setcode do
    require 'puppet'

    basepath = '/usr/share'

    files = Dir.entries(basepath).select { |d| /jetty-distribution/.match(d) }
    files.reject! { |f| File.lstat("#{basepath}/#{f}").symlink? }
    files.sort! { |a,b| Puppet::Util::Package.versioncmp(a.split('-')[2], b.split('-')[2]) }

    if(files.nil? or files == [])
      nil
    else
      files[-1]
    end
  end
end
